/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{html,js,svelte,ts}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif']
      },
      colors: {
        surface: {
          base: '#0c0c12',
          card: '#13131c',
          input: '#0f0f18',
          hover: '#1a1a26'
        },
        accent: {
          DEFAULT: '#6366f1',
          hover: '#818cf8',
          muted: '#a5b4fc',
          bg: 'rgba(99, 102, 241, 0.06)',
          border: 'rgba(99, 102, 241, 0.18)'
        }
      }
    }
  },
  plugins: []
};
